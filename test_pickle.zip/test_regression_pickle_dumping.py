from pyspark import SparkContext
import numpy as np
from pyspark.ml.classification import LogisticRegression
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.util import MLUtils
from pyspark.sql import SQLContext

sc = SparkContext(appName="Simple App")
sqlContext = SQLContext(sc)

# Load training data
training = MLUtils.loadLibSVMFile(sc, "data/mllib/sample_libsvm_data.txt").toDF()

lr = LogisticRegression(maxIter=10, regParam=0.3, elasticNetParam=0.8)

# Fit the model
lrModel = lr.fit(training)

# Print the weights and intercept for logistic regression
print("Weights: " + str(lrModel.weights))
print("Intercept: " + str(lrModel.intercept))


# j'ai essaye de resoudre le probleme en rajoutant une methode __gestate__
# a la classe du modele. Ca supprime l'erreur au moment du dump mais ca en fait apparaitre
# une autre au moment du load
#setattr(type(lrModel), "__getstate__", classmethod(lambda self: self.__dict__))
#setattr(type(lrModel), "__setstate__", classmethod(lambda (self, d): self.__dict__.update(d)))

import pickle

output=file('./sauvegarde_lr.txt','w')
pickle.dump(lrModel,output)
output.close()
