from pyspark import SparkContext
import numpy as np
from pyspark.ml.classification import LogisticRegression
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.util import MLUtils
from pyspark.sql import SQLContext

sc = SparkContext(appName="Simple App")
sqlContext = SQLContext(sc)

import pickle

input=file('./sauvegarde_lr.txt','r')
lrModel = pickle.load(input)
input.close()

print("Weights: " + str(lrModel.weights))
print("Intercept: " + str(lrModel.intercept))
